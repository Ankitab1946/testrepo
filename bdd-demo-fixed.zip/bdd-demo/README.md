# BDD + Gherkin End-to-End Demo (Fixed)

Plain English → Gherkin (AWS Bedrock or deterministic fallback) → Behave execution (DB/API/UI) → Cucumber JSON → Xray.
This build fixes:
- `ModuleNotFoundError: app` by adding `app/__init__.py` and sys.path bootstrap in scripts.
- More reliable English→Gherkin via a deterministic converter (still uses Bedrock when configured).

## Quick Start
```bash
python -m venv .venv
# Windows: . .venv/Scripts/activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp sample.env .env

# 1) Start mock API/UI
uvicorn services.api_mock.main:app --reload --port 9000

# 2) Start Streamlit UI
streamlit run app/streamlit_app.py
```

Then: Type your requirement → Convert → Save → Run Behave → Upload to Xray (demo or real) → Download Summary.

CLI:
```bash
python scripts/run_behave.py
pytest tests/pytest -q
python scripts/upload_to_xray.py
```
