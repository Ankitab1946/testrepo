import os, sys, subprocess
# Ensure project root on sys.path
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
from app.config import settings

def main():
    os.makedirs(settings.reports_dir, exist_ok=True)
    cmd = [sys.executable, "-m", "behave",
           "-f", "progress",
           "-f", "json.pretty",
           "-o", os.path.join(settings.reports_dir, "cucumber_report.json"),
           "features"]
    print("Running:", " ".join(cmd))
    res = subprocess.run(cmd, cwd=settings.base_dir)
    print("Behave exit code:", res.returncode)
    sys.exit(res.returncode)

if __name__ == "__main__":
    main()
