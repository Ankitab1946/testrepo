import os, io, json, subprocess, glob, time
import streamlit as st
from jinja2 import Template
from app.config import settings
from app.bedrock_client import english_to_gherkin
from app.xray_client import XrayClient

st.set_page_config(page_title="BDD + Gherkin Demo", layout="wide")
st.title("🧪 BDD + Gherkin End-to-End Demo")
st.caption("Plain English → Gherkin (Bedrock or deterministic), Behave, screenshots, Cucumber JSON → Xray")

with st.sidebar:
    st.header("Config")
    st.write(f"DB: **{settings.db_mode}** | AWS region: **{settings.aws_region}**")
    st.write(f"Reports: `{settings.reports_dir}`")
    st.write(f"Screenshots: `{settings.screenshots_dir}`")
    st.write("---")
    st.write("**Jira/Xray**")
    st.write(f"Base: `{settings.jira_base_url or '(not set)'}` | Deploy: `{settings.xray_deployment}`")

st.subheader("1) Write requirement in plain English")
plain = st.text_area("Requirement", height=160, placeholder="e.g., Check feed vs DB count and types; also API score range; UI shows Client A revenue")

if st.button("Convert to Gherkin (Bedrock)"):
    gherkin = english_to_gherkin(plain)
    st.session_state["gherkin"] = gherkin
    st.success("Generated Gherkin")
    st.code(gherkin, language="gherkin")

if "gherkin" in st.session_state:
    st.subheader("2) Save Feature File")
    fname = st.text_input("Feature file name", value="generated.feature")
    if st.button("Save Feature File"):
        path = os.path.join(settings.features_dir, fname)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(st.session_state["gherkin"])
        st.success(f"Saved: {path}")
        st.session_state["saved_feature"] = path

st.subheader("3) Run Behave Now")
if st.button("Run Behave Now"):
    st.write("Running...")
    cmd = ["python", "scripts/run_behave.py"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=settings.base_dir)
    out = io.StringIO()
    for line in proc.stdout:
        st.write(line.rstrip())
        out.write(line)
    proc.wait()
    st.session_state["behave_output"] = out.getvalue()
    st.session_state["cucumber_path"] = os.path.join(settings.reports_dir, "cucumber_report.json")
    st.success("Behave run finished")

if "behave_output" in st.session_state:
    st.text_area("Console output", st.session_state["behave_output"], height=220)

st.subheader("Artifacts")
screens = sorted(glob.glob(os.path.join(settings.screenshots_dir, "*.png")))
st.write(f"📸 Screenshots ({len(screens)}):")
for s in screens[-8:]:
    st.image(s, caption=os.path.basename(s), use_column_width=True)

if os.path.exists(os.path.join(settings.reports_dir, "cucumber_report.json")):
    with open(os.path.join(settings.reports_dir, "cucumber_report.json"), "r", encoding="utf-8") as f:
        st.json(json.load(f))

st.subheader("4) Upload result to Xray")
if st.button("Upload Result to Xray"):
    res = XrayClient().upload_cucumber(os.path.join(settings.reports_dir,"cucumber_report.json"), screens)
    st.session_state["xray_result"] = res
    st.success("Uploaded (or simulated).")

if "xray_result" in st.session_state:
    st.json(st.session_state["xray_result"])
    url = st.session_state["xray_result"].get("test_execution_url")
    if url:
        st.link_button("Open Test Execution in Jira", url)

st.subheader("5) Download Test Execution Summary")
if st.button("Generate & Download Summary"):
    template = Template("""
    <html><head><meta charset='utf-8'><title>Test Execution Summary</title></head>
    <body>
      <h1>Test Execution Summary</h1>
      <p>Generated at: {{ ts }}</p>
      <h2>cucumber_report.json</h2>
      <pre>{{ cucumber|e }}</pre>
      <h2>Screenshots</h2>
      {% for s in screenshots %}
        <div><p>{{ s }}</p><img src="{{ s }}" width="600"/></div>
      {% endfor %}
    </body></html>
    """)
    cuc_path = os.path.join(settings.reports_dir, "cucumber_report.json")
    cuc_text = ""
    if os.path.exists(cuc_path):
        with open(cuc_path,"r",encoding="utf-8") as f: cuc_text = f.read()
    html = template.render(ts=time.ctime(), cucumber=cuc_text, screenshots=[os.path.relpath(s, settings.base_dir) for s in screens])
    out_path = os.path.join(settings.reports_dir, "test_execution_summary.html")
    with open(out_path,"w",encoding="utf-8") as f: f.write(html)
    with open(out_path,"rb") as f:
        st.download_button("Download Summary HTML", f, file_name="test_execution_summary.html", mime="text/html")

st.info(f"Start mock API/UI: `uvicorn services.api_mock.main:app --reload --port {settings.mock_service_port}`")
