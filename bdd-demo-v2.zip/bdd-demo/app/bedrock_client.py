from __future__ import annotations
import json
from .config import settings

try:
    import boto3
except Exception:
    boto3 = None

SYSTEM_PROMPT = (
    "You convert short plain-English testing requirements into valid Gherkin for Behave.\n"
    "Output ONLY Gherkin. Steps must match these capabilities: DB count/type checks,\n"
    "API range check via Great Expectations, UI revenue check via Selenium.\n"
)

FEW_SHOT = (
    "Feature: Data pipeline integrity\n"
    "  Scenario: Feed count parity\n"
    "    Given the demo database is initialized\n"
    "    And the CSV feed 'data/feed/sample_feed.csv' is available\n"
    "    When I load the feed into the 'transactions' table\n"
    "    Then the row count in 'transactions' should equal the row count in the feed\n"
)

def _deterministic_converter(text: str) -> str:
    t = text.lower()
    has_feed = any(k in t for k in ["feed", "sql server", "sqlite", "db", "database"])
    has_api = any(k in t for k in ["api", "range", "great expectation", "great expectations", "score"])
    has_ui  = any(k in t for k in ["ui", "revenue", "client a", "browser", "selenium"])

    scenarios = []
    if has_feed:
        scenarios.append(
            "  Scenario: Feed and DB row counts match\n"
            "    Given the demo database is initialized\n"
            "    And the CSV feed 'data/feed/sample_feed.csv' is available\n"
            "    When I load the feed into the 'transactions' table\n"
            "    Then the row count in 'transactions' should equal the row count in the feed\n"
            "    And the column types should match expected schema\n"
        )
    if has_api:
        scenarios.append(
            "  Scenario: Score is within range\n"
            "    When I request the score for client 'A' from the mock API\n"
            "    Then the 'score' value should be between 0 and 100\n"
        )
    if has_ui:
        scenarios.append(
            "  Scenario: Client A revenue is displayed correctly\n"
            "    When I open the clients revenue page\n"
            "    Then the revenue for client 'A' should equal the expected value\n"
        )
    if scenarios:
        return "Feature: End-to-end validation\n" + "".join(scenarios)
    return FEW_SHOT

def english_to_gherkin(plain_english: str) -> str:
    text = (plain_english or "").strip()
    if not text:
        return FEW_SHOT

    if boto3 and settings.aws_access_key_id and settings.aws_secret_access_key:
        try:
            bedrock = boto3.client("bedrock-runtime", region_name=settings.aws_region)
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "system": SYSTEM_PROMPT,
                "messages": [{"role":"user","content":[{"type":"text","text": text}]}],
                "max_tokens": 800,
                "temperature": 0.2,
            }
            resp = bedrock.invoke_model(
                modelId=settings.bedrock_model,
                body=json.dumps(body),
                contentType="application/json",
                accept="application/json",
            )
            out = json.loads(resp.get("body").read().decode("utf-8"))
            if isinstance(out, dict) and "content" in out:
                g = "".join(p.get("text","") for p in out["content"] if p.get("type")=="text")
                if g.strip():
                    return g.strip()
        except Exception:
            pass

    return _deterministic_converter(text)
