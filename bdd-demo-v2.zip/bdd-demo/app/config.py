import os
from dataclasses import dataclass

# Make python-dotenv optional
try:
    from dotenv import load_dotenv
except Exception:
    def load_dotenv(*args, **kwargs):
        return False

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
dot_env = os.path.join(base_dir, ".env")
if os.path.exists(dot_env):
    load_dotenv(dot_env)

@dataclass
class Settings:
    aws_access_key_id: str = os.getenv("AWS_ACCESS_KEY_ID", "")
    aws_secret_access_key: str = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    aws_session_token: str = os.getenv("AWS_SESSION_TOKEN", "")
    aws_region: str = os.getenv("AWS_REGION", "us-east-1")
    bedrock_model: str = os.getenv("BEDROCK_MODEL", "anthropic.claude-3-5-sonnet-20240620")

    jira_base_url: str = os.getenv("JIRA_BASE_URL", "")
    jira_user_email: str = os.getenv("JIRA_USER_EMAIL", "")
    jira_api_token: str = os.getenv("JIRA_API_TOKEN", "")
    xray_deployment: str = os.getenv("XRAY_DEPLOYMENT", "cloud")
    xray_client_id: str = os.getenv("XRAY_CLIENT_ID", "")
    xray_client_secret: str = os.getenv("XRAY_CLIENT_SECRET", "")

    db_mode: str = os.getenv("DB_MODE", "sqlite")
    sqlserver_server: str = os.getenv("SQLSERVER_SERVER", "localhost")
    sqlserver_database: str = os.getenv("SQLSERVER_DATABASE", "master")

    headless: bool = os.getenv("HEADLESS", "true").lower() == "true"

    expected_revenue_client_a: int = int(os.getenv("EXPECTED_REVENUE_CLIENT_A", "125000"))
    mock_service_port: int = int(os.getenv("MOCK_SERVICE_PORT", "9000"))

    base_dir: str = base_dir
    features_dir: str = os.path.join(base_dir, "features")
    reports_dir: str = os.path.join(base_dir, "reports")
    screenshots_dir: str = os.path.join(base_dir, "selenium", "screenshots")
    data_dir: str = os.path.join(base_dir, "data")

settings = Settings()
os.makedirs(settings.reports_dir, exist_ok=True)
os.makedirs(settings.screenshots_dir, exist_ok=True)
