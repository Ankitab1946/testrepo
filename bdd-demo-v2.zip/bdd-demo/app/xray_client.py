from __future__ import annotations
import os, json, requests
from typing import List, Dict
from .config import settings

class XrayClient:
    def __init__(self):
        self.base_url = settings.jira_base_url.rstrip('/') if settings.jira_base_url else ""
        self.user_email = settings.jira_user_email
        self.api_token = settings.jira_api_token
        self.deployment = settings.xray_deployment
        self.client_id = settings.xray_client_id
        self.client_secret = settings.xray_client_secret

    def is_configured(self) -> bool:
        if self.deployment == "cloud":
            return bool(self.client_id and self.client_secret)
        return bool(self.base_url and self.user_email and self.api_token)

    def _cloud_auth_token(self) -> str:
        url = "https://xray.cloud.getxray.app/api/v2/authenticate"
        r = requests.post(url, json={"client_id": self.client_id, "client_secret": self.client_secret}, timeout=30)
        r.raise_for_status()
        token = r.json()
        return token.strip('"') if isinstance(token, str) else token

    def upload_cucumber(self, cucumber_json_path: str, screenshots: List[str]) -> Dict:
        log_path = os.path.join(settings.reports_dir, "xray_upload_log.json")
        if not os.path.exists(cucumber_json_path):
            result = {"status":"error","message":f"Missing {cucumber_json_path}"}
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
            return result

        if not self.is_configured():
            result = {
                "status":"demo",
                "test_execution_key":"DEMO-TE-1",
                "test_execution_url": f"{self.base_url}/browse/DEMO-TE-1" if self.base_url else "",
                "tests":["DEMO-T-1","DEMO-T-2","DEMO-T-3"],
                "screenshots_attached":[os.path.basename(s) for s in screenshots if os.path.exists(s)]
            }
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
            return result

        if self.deployment == "cloud":
            token = self._cloud_auth_token()
            import_url = "https://xray.cloud.getxray.app/api/v2/import/execution/cucumber"
            headers = {"Authorization": f"Bearer {token}"}
            with open(cucumber_json_path, "rb") as f:
                r = requests.post(import_url, headers=headers, files={"file": f}, timeout=60)
            r.raise_for_status()
            resp = r.json()
            te_key = resp.get("key") or resp.get("testExecIssue",{}).get("key","")
            te_url = f"{self.base_url}/browse/{te_key}" if te_key and self.base_url else ""
            return {"status":"ok","test_execution_key":te_key,"test_execution_url":te_url,"raw":resp}

        import_url = f"{self.base_url}/rest/raven/1.0/import/execution/cucumber"
        auth = (self.user_email, self.api_token)
        with open(cucumber_json_path, "rb") as f:
            r = requests.post(import_url, auth=auth, files={"file": f}, timeout=60)
        r.raise_for_status()
        resp = r.json() if r.headers.get("content-type","").startswith("application/json") else {"raw": r.text}
        te_key = resp.get("testExecIssue",{}).get("key","")
        te_url = f"{self.base_url}/browse/{te_key}" if te_key else ""
        return {"status":"ok","test_execution_key":te_key,"test_execution_url":te_url,"raw":resp}
