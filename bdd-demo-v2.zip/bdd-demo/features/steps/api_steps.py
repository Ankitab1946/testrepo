import requests, pandas as pd
from behave import when, then
from app.config import settings

def ge_range_check(value, min_v, max_v):
    try:
        import great_expectations as ge
        df = pd.DataFrame({'score':[value]})
        try:
            gdf = ge.from_pandas(df)
            result = gdf.expect_column_values_to_be_between('score', min_value=min_v, max_value=max_v)
            return bool(result.success)
        except Exception:
            return (min_v <= value <= max_v)
    except Exception:
        return (min_v <= value <= max_v)

@when("I request the score for client 'A' from the mock API")
def step_impl(context):
    url = f"http://127.0.0.1:{settings.mock_service_port}/score?client=A"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    context.api_json = r.json()

@then("the 'score' value should be between 0 and 100")
def step_impl(context):
    score = float(context.api_json.get("score", -999))
    assert ge_range_check(score, 0, 100), f"Score out of range: {score}"
