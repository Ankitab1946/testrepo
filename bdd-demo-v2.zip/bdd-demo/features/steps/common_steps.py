from behave import given

@given('the demo database is initialized')
def step_impl(context):
    context.initialized = True
