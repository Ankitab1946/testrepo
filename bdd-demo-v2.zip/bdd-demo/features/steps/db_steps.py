import os, sqlite3
from behave import given, when, then
from app.config import settings
import pandas as pd

DB_PATH = os.path.join(settings.base_dir, "data", "demo.sqlite")

def ensure_sqlite():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    if not os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        with open(os.path.join(settings.base_dir, "data", "db", "bootstrap_sqlite.sql"), "r", encoding="utf-8") as f:
            conn.executescript(f.read())
        conn.commit()
        conn.close()

@given("the CSV feed 'data/feed/sample_feed.csv' is available")
def step_impl(context):
    path = os.path.join(settings.base_dir, "data", "feed", "sample_feed.csv")
    assert os.path.exists(path), f"Feed not found: {path}"
    context.feed_path = path

@when("I load the feed into the 'transactions' table")
def step_impl(context):
    ensure_sqlite()
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_csv(context.feed_path)
    df.to_sql("transactions", conn, if_exists="replace", index=False)
    conn.commit()
    conn.close()

@then("the row count in 'transactions' should equal the row count in the feed")
def step_impl(context):
    ensure_sqlite()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM transactions")
    db_count = cur.fetchone()[0]
    conn.close()
    feed_count = pd.read_csv(context.feed_path).shape[0]
    assert db_count == feed_count, f"DB has {db_count}, feed has {feed_count}"

@then("the column types should match expected schema")
def step_impl(context):
    ensure_sqlite()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(transactions)")
    cols = {row[1]: row[2].upper() for row in cur.fetchall()}
    conn.close()
    assert cols.get("id","").startswith("INTEGER"), f"id type: {cols.get('id')}"
    assert "TEXT" in cols.get("name",""), f"name type: {cols.get('name')}"
    assert "REAL" in cols.get("amount","") or "FLOAT" in cols.get("amount",""), f"amount type: {cols.get('amount')}"
    assert "TEXT" in cols.get("created_at",""), f"created_at type: {cols.get('created_at')}"
