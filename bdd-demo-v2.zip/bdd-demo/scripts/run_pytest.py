import os, sys, subprocess
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
from app.config import settings

def main():
    cmd = [sys.executable, "-m", "pytest", "tests/pytest", "-q"]
    print("Running:", " ".join(cmd))
    res = subprocess.run(cmd, cwd=settings.base_dir)
    print("pytest exit code:", res.returncode)
    sys.exit(res.returncode)

if __name__ == "__main__":
    main()
