import os, sys, glob, json
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
from app.config import settings
from app.xray_client import XrayClient

def main():
    cucumber = os.path.join(settings.reports_dir, "cucumber_report.json")
    screens = glob.glob(os.path.join(settings.screenshots_dir, "*.png"))
    res = XrayClient().upload_cucumber(cucumber, screens)
    print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
