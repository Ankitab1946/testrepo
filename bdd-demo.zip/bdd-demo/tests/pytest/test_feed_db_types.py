import os, sqlite3

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DB_PATH = os.path.join(BASE, 'data', 'demo.sqlite')

def test_types():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('PRAGMA table_info(transactions)')
    cols = {row[1]: row[2].upper() for row in cur.fetchall()}
    conn.close()
    assert cols.get('id','').startswith('INTEGER')
    assert 'TEXT' in cols.get('name','')
    assert 'REAL' in cols.get('amount','') or 'FLOAT' in cols.get('amount','')
    assert 'TEXT' in cols.get('created_at','')
