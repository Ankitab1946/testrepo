import os, sqlite3, pandas as pd

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DB_PATH = os.path.join(BASE, 'data', 'demo.sqlite')

def test_feed_db_count():
    feed = os.path.join(BASE, 'data', 'feed', 'sample_feed.csv')
    assert os.path.exists(feed)
    df = pd.read_csv(feed)
    # ensure db exists
    conn = sqlite3.connect(DB_PATH)
    df.to_sql('transactions', conn, if_exists='replace', index=False)
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM transactions')
    db_count = cur.fetchone()[0]
    conn.close()
    assert db_count == len(df)
