import os
from app.config import settings

def before_all(context):
    os.makedirs(settings.reports_dir, exist_ok=True)
    os.makedirs(settings.screenshots_dir, exist_ok=True)
