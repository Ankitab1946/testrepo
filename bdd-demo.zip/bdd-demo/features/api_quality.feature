Feature: API data quality
  Scenario: Score is within range
    When I request the score for client 'A' from the mock API
    Then the 'score' value should be between 0 and 100
