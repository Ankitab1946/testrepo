Feature: Feed to DB validation
  Scenario: Feed and DB row counts match
    Given the demo database is initialized
    And the CSV feed 'data/feed/sample_feed.csv' is available
    When I load the feed into the 'transactions' table
    Then the row count in 'transactions' should equal the row count in the feed
    And the column types should match expected schema
