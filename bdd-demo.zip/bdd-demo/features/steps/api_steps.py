import os, requests, pandas as pd
from behave import when, then
from app.config import settings

# Great Expectations can be heavy; provide a graceful fallback
def ge_range_check(value, min_v, max_v):
    try:
        import great_expectations as ge
        # Older API compatibility
        try:
            df = ge.from_pandas(pd.DataFrame({'score':[value]}))
            result = df.expect_column_values_to_be_between('score', min_value=min_v, max_value=max_v)
            return bool(result.success)
        except Exception:
            # Newer API approach
            from great_expectations.execution_engine import PandasExecutionEngine
            from great_expectations.validator.validator import Validator
            from great_expectations.core.batch import Batch
            from great_expectations.core.expectation_configuration import ExpectationConfiguration
            import pandas as pd
            engine = PandasExecutionEngine()
            batch = Batch(data=pd.DataFrame({'score':[value]}))
            validator = Validator(execution_engine=engine, batches=[batch])
            cfg = ExpectationConfiguration(
                expectation_type="expect_column_values_to_be_between",
                kwargs={"column":"score","min_value":min_v,"max_value":max_v}
            )
            res = validator.evaluate(expectation_suite={"expectations":[cfg.to_json_dict()]})
            return all(r.success for r in res.results)
    except Exception:
        # Fallback: simple check
        return min_v <= value <= max_v

@when("I request the score for client 'A' from the mock API")
def step_impl(context):
    url = f"http://127.0.0.1:{settings.mock_service_port}/score?client=A"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    context.api_json = r.json()

@then("the 'score' value should be between 0 and 100")
def step_impl(context):
    score = float(context.api_json.get("score", -999))
    ok = ge_range_check(score, 0, 100)
    assert ok, f"Score out of range: {score}"
