import os, time, json
from behave import given, when, then
from app.config import settings

@given("the demo database is initialized")
def step_impl(context):
    # Nothing special here; db setup happens in DB steps when needed
    context.initialized = True
