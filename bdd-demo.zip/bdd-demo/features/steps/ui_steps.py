import os, time
from behave import when, then
from app.config import settings

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

def _make_driver():
    opts = Options()
    if settings.headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=opts)
    driver.set_window_size(1280, 800)
    return driver

@when("I open the clients revenue page")
def step_impl(context):
    context.driver = _make_driver()
    url = f"http://127.0.0.1:{settings.mock_service_port}/clients"
    context.driver.get(url)
    time.sleep(0.5)

@then("the revenue for client 'A' should equal the expected value")
def step_impl(context):
    driver = context.driver
    # Find the row where first cell is 'A'
    rows = driver.find_elements(By.CSS_SELECTOR, "table#clients tbody tr")
    value = None
    for r in rows:
        cells = r.find_elements(By.TAG_NAME, "td")
        if len(cells) >= 2 and cells[0].text.strip() == "A":
            value = int(cells[1].text.strip().replace(',', ''))
            break
    # Screenshot always
    os.makedirs(settings.screenshots_dir, exist_ok=True)
    out = os.path.join(settings.screenshots_dir, f"ui_revenue_{int(time.time())}.png")
    driver.save_screenshot(out)
    driver.quit()
    assert value == settings.expected_revenue_client_a, f"Expected {settings.expected_revenue_client_a}, got {value}"
