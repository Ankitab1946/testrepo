Feature: UI revenue
  Scenario: Client A revenue is displayed correctly
    When I open the clients revenue page
    Then the revenue for client 'A' should equal the expected value
