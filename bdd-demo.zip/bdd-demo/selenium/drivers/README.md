Chrome must be installed locally. The tests use webdriver-manager to auto-download the driver.
If running in a locked-down environment, set PATH to an existing chromedriver.
