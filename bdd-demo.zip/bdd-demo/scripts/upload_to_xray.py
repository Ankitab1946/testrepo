import os, glob, json
from app.config import settings
from app.xray_client import XrayClient

def main():
    cucumber = os.path.join(settings.reports_dir, "cucumber_report.json")
    screens = glob.glob(os.path.join(settings.screenshots_dir, "*.png"))
    client = XrayClient()
    res = client.upload_cucumber(cucumber, screens)
    print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
