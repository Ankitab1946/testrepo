import os, sys, subprocess
from app.config import settings

def main():
    cmd = [sys.executable, "-m", "pytest", "tests/pytest", "-q"]
    print("Running:", " ".join(cmd))
    res = subprocess.run(cmd, cwd=settings.base_dir)
    print("pytest exit code:", res.returncode)
    sys.exit(res.returncode)

if __name__ == "__main__":
    main()
