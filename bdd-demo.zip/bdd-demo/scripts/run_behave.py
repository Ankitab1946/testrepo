import os, sys, subprocess, json, shutil
from app.config import settings

def main():
    # Ensure reports dir
    os.makedirs(settings.reports_dir, exist_ok=True)

    cmd = [
        sys.executable, "-m", "behave",
        "-f", "progress",
        "-f", "json.pretty",
        "-o", os.path.join(settings.reports_dir, "cucumber_report.json"),
        "features"
    ]
    print("Running:", " ".join(cmd))
    res = subprocess.run(cmd, cwd=settings.base_dir)
    print("Behave exit code:", res.returncode)
    sys.exit(res.returncode)

if __name__ == "__main__":
    main()
