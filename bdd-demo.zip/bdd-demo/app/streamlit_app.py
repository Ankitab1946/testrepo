import os, io, json, subprocess, time, glob, webbrowser
import streamlit as st
from jinja2 import Template
from app.config import settings
from app.bedrock_client import english_to_gherkin
from app.xray_client import XrayClient

st.set_page_config(page_title="BDD + Gherkin Demo", layout="wide")

st.title("🧪 BDD + Gherkin End‑to‑End Demo")
st.caption("Plain English → Gherkin (Bedrock), Behave execution, screenshots, Cucumber JSON → Xray")

with st.sidebar:
    st.header("Config")
    st.text("These read from .env (if present)")
    st.write(f"DB mode: **{settings.db_mode}**  |  Region: **{settings.aws_region}**")
    st.write(f"Reports: `{settings.reports_dir}`")
    st.write(f"Screenshots: `{settings.screenshots_dir}`")
    st.write("---")
    st.write("**Jira/Xray** (optional):")
    st.write(f"Base URL: `{settings.jira_base_url or '(not set)'}`")
    st.write(f"Deployment: `{settings.xray_deployment}`")

st.subheader("1) Write requirement in plain English")
plain = st.text_area("Requirement", height=160, placeholder="e.g., Validate that API score is in 0..100")

if st.button("Convert to Gherkin (Bedrock)"):
    gherkin = english_to_gherkin(plain)
    st.session_state["gherkin"] = gherkin
    st.success("Generated Gherkin")
    st.code(gherkin, language="gherkin")

if "gherkin" in st.session_state:
    st.subheader("2) Save Feature File")
    default_name = "generated.feature"
    fname = st.text_input("Feature file name", value=default_name)
    if st.button("Save Feature File"):
        path = os.path.join(settings.features_dir, fname)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(st.session_state["gherkin"])
        st.success(f"Saved: {path}")
        st.session_state["saved_feature"] = path

st.subheader("3) Run Behave live")
col1, col2 = st.columns([1,1])
with col1:
    if st.button("Run Behave Now"):
        st.write("Running...")
        cmd = ["python", "scripts/run_behave.py"]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        output = io.StringIO()
        for line in proc.stdout:
            st.write(line.rstrip())
            output.write(line)
        proc.wait()
        st.session_state["behave_output"] = output.getvalue()
        st.session_state["cucumber_path"] = os.path.join(settings.reports_dir, "cucumber_report.json")
        st.success("Behave run finished")

with col2:
    if "behave_output" in st.session_state:
        st.text_area("Console output", st.session_state["behave_output"], height=240)

st.subheader("Artifacts")
screens = sorted(glob.glob(os.path.join(settings.screenshots_dir, "*.png")))
st.write(f"📸 Screenshots ({len(screens)}):")
for s in screens[-8:]:
    st.image(s, caption=os.path.basename(s), use_column_width=True)

if os.path.exists(os.path.join(settings.reports_dir, "cucumber_report.json")):
    with open(os.path.join(settings.reports_dir, "cucumber_report.json"), "r", encoding="utf-8") as f:
        data = json.load(f)
    st.write("Cucumber JSON loaded")
    with st.expander("cucumber_report.json"):
        st.json(data)

st.subheader("4) Upload result to Xray")
if st.button("Upload Result to Xray"):
    client = XrayClient()
    res = client.upload_cucumber(
        os.path.join(settings.reports_dir, "cucumber_report.json"),
        screens
    )
    st.session_state["xray_result"] = res
    if res.get("status") in ("ok","demo"):
        st.success("Uploaded (or simulated).")
    else:
        st.error(f"Failed: {res}")

if "xray_result" in st.session_state:
    st.write("Xray response:")
    st.json(st.session_state["xray_result"])
    url = st.session_state["xray_result"].get("test_execution_url")
    if url:
        st.link_button("Open Test Execution in Jira", url)

st.subheader("5) Download Test Execution Summary (with evidences)")
if st.button("Generate & Download Summary"):
    template = Template("""
    <html>
    <head><meta charset="utf-8"><title>Test Execution Summary</title></head>
    <body>
      <h1>Test Execution Summary</h1>
      <p>Generated at: {{ ts }}</p>
      <h2>Scenarios</h2>
      <pre>{{ cucumber|e }}</pre>
      <h2>Screenshots</h2>
      {% for s in screenshots %}
        <div>
          <p>{{ s }}</p>
          <img src="{{ s }}" width="600" />
        </div>
      {% endfor %}
    </body>
    </html>
    """)
    cucumber_path = os.path.join(settings.reports_dir, "cucumber_report.json")
    cucumber_text = ""
    if os.path.exists(cucumber_path):
        with open(cucumber_path, "r", encoding="utf-8") as f:
            cucumber_text = f.read()
    html = template.render(ts=time.ctime(), cucumber=cucumber_text, screenshots=[os.path.relpath(s, settings.base_dir) for s in screens])
    out_path = os.path.join(settings.reports_dir, "test_execution_summary.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    st.success(f"Summary generated: {out_path}")
    with open(out_path, "rb") as f:
        st.download_button("Download Summary HTML", data=f, file_name="test_execution_summary.html", mime="text/html")

st.divider()
st.info("Tip: Start the mock API/UI: `uvicorn services.api_mock.main:app --reload --port {}`".format(settings.mock_service_port))
