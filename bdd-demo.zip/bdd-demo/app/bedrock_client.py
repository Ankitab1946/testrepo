from __future__ import annotations
import json
import os
from typing import Optional
from .config import settings

# Optional boto3 import; handle missing gracefully
try:
    import boto3
except Exception:
    boto3 = None

SYSTEM_PROMPT = (    "You convert short plain-English testing requirements into valid Gherkin for Behave.\n"
    "Output ONLY Gherkin. Use clear steps that match these capabilities: DB count/type checks,\n"
    "API range check via Great Expectations, UI revenue check via Selenium.\n"
    "Ensure Feature/Scenario/Given/When/Then syntax.\n"
)

FEW_SHOT = (
    "Feature: Data pipeline integrity\n"
    "  Scenario: Feed count parity\n"
    "    Given the demo database is initialized\n"
    "    And the CSV feed 'data/feed/sample_feed.csv' is available\n"
    "    When I load the feed into the 'transactions' table\n"
    "    Then the row count in 'transactions' should equal the row count in the feed\n"
)

def english_to_gherkin(plain_english: str) -> str:
    """Convert plain English to Gherkin using AWS Bedrock (Claude) if configured; else fallback."""
    text = plain_english.strip()
    if not text:
        return FEW_SHOT

    # Try Bedrock if possible
    if boto3 and settings.aws_access_key_id and settings.aws_secret_access_key:
        try:
            bedrock = boto3.client("bedrock-runtime", region_name=settings.aws_region)
            model = settings.bedrock_model
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "system": SYSTEM_PROMPT,
                "messages": [
                    {"role": "user", "content": [{"type":"text","text": text}]}
                ],
                "max_tokens": 800,
                "temperature": 0.2,
            }
            resp = bedrock.invoke_model(
                modelId=model,
                body=json.dumps(body),
                contentType="application/json",
                accept="application/json",
            )
            model_output = json.loads(resp.get("body").read().decode("utf-8"))
            # Claude style: {"content":[{"type":"text","text":"..."}]}
            if isinstance(model_output, dict) and "content" in model_output:
                parts = model_output["content"]
                txt = ""
                for p in parts:
                    if p.get("type") == "text":
                        txt += p.get("text","")
                if txt.strip():
                    return txt.strip()
        except Exception as e:
            # Fall back below
            pass

    # Fallback: simple heuristic mapping to one of the three demo features
    text_low = text.lower()
    if "api" in text_low or "range" in text_low:
        return (
            "Feature: API data quality\n"
            "  Scenario: Score is within range\n"
            "    When I request the score for client 'A' from the mock API\n"
            "    Then the 'score' value should be between 0 and 100\n"
        )
    if "ui" in text_low or "revenue" in text_low:
        return (
            "Feature: UI revenue\n"
            "  Scenario: Client A revenue is displayed correctly\n"
            "    When I open the clients revenue page\n"
            "    Then the revenue for client 'A' should equal the expected value\n"
        )
    # default: feed/db
    return (
        "Feature: Feed to DB validation\n"
        "  Scenario: Feed and DB row counts match\n"
        "    Given the demo database is initialized\n"
        "    And the CSV feed 'data/feed/sample_feed.csv' is available\n"
        "    When I load the feed into the 'transactions' table\n"
        "    Then the row count in 'transactions' should equal the row count in the feed\n"
    )
