from __future__ import annotations
import os, json, time
from typing import Dict, List, Tuple
import requests
from .config import settings

class XrayClient:
    def __init__(self):
        self.base_url = settings.jira_base_url.rstrip('/') if settings.jira_base_url else ""
        self.user_email = settings.jira_user_email
        self.api_token = settings.jira_api_token
        self.deployment = settings.xray_deployment
        self.client_id = settings.xray_client_id
        self.client_secret = settings.xray_client_secret

    def is_configured(self) -> bool:
        # Either Cloud OAuth2 or Server/DC basic
        if self.deployment == "cloud":
            return bool(self.client_id and self.client_secret)
        else:
            return bool(self.base_url and self.user_email and self.api_token)

    def _cloud_auth_token(self) -> str:
        url = "https://xray.cloud.getxray.app/api/v2/authenticate"
        payload = {"client_id": self.client_id, "client_secret": self.client_secret}
        r = requests.post(url, json=payload, timeout=30)
        r.raise_for_status()
        token = r.json()
        if isinstance(token, str):
            return token.strip('"')
        return token

    def upload_cucumber(self, cucumber_json_path: str, screenshots: List[str]) -> Dict:
        """Upload cucumber JSON to Xray. If not configured, simulate for demo."""
        log_path = os.path.join(settings.reports_dir, "xray_upload_log.json")

        if not os.path.exists(cucumber_json_path):
            result = {"status": "error", "message": f"Cucumber JSON not found: {cucumber_json_path}"}
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
            return result

        if not self.is_configured():
            # Demo mode: simulate an upload
            dummy_te_key = "DEMO-TE-1"
            result = {
                "status": "demo",
                "test_execution_key": dummy_te_key,
                "test_execution_url": f"{self.base_url}/browse/{dummy_te_key}" if self.base_url else "",
                "tests": ["DEMO-T-1", "DEMO-T-2", "DEMO-T-3"],
                "screenshots_attached": [os.path.basename(p) for p in screenshots if os.path.exists(p)],
            }
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
            return result

        # Real upload
        if self.deployment == "cloud":
            token = self._cloud_auth_token()
            import_url = "https://xray.cloud.getxray.app/api/v2/import/execution/cucumber"
            headers = {"Authorization": f"Bearer {token}"}
            with open(cucumber_json_path, "rb") as f:
                r = requests.post(import_url, headers=headers, files={"file": f}, timeout=60)
            r.raise_for_status()
            resp = r.json()
            te_key = resp.get("key") or resp.get("testExecIssue", {}).get("key", "")
            te_url = f"{self.base_url}/browse/{te_key}" if te_key and self.base_url else ""
            # Attach screenshots to Test Execution
            if te_key and self.base_url:
                self._attach_to_issue(te_key, screenshots)
            result = {"status": "ok", "test_execution_key": te_key, "test_execution_url": te_url, "raw": resp}
        else:
            # Server/DC expects POST to {JIRA_BASE_URL}/rest/raven/1.0/import/execution/cucumber
            import_url = f"{self.base_url}/rest/raven/1.0/import/execution/cucumber"
            auth = (self.user_email, self.api_token)
            with open(cucumber_json_path, "rb") as f:
                r = requests.post(import_url, auth=auth, files={"file": f}, timeout=60)
            r.raise_for_status()
            resp = r.json() if r.headers.get("content-type","").startswith("application/json") else {"raw": r.text}
            te_key = resp.get("testExecIssue", {}).get("key", "")
            te_url = f"{self.base_url}/browse/{te_key}" if te_key else ""
            if te_key:
                self._attach_to_issue(te_key, screenshots, auth=auth)
            result = {"status": "ok", "test_execution_key": te_key, "test_execution_url": te_url, "raw": resp}

        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)
        return result

    def _attach_to_issue(self, issue_key: str, files: List[str], auth=None):
        """Attach screenshot files to a Jira issue (usually the Test Execution)."""
        if not files:
            return
        url = f"{self.base_url}/rest/api/2/issue/{issue_key}/attachments"
        headers = {
            "X-Atlassian-Token": "no-check",
        }
        if auth is None:
            # cloud with bearer token not supported here; skip in demo
            return
        for path in files:
            if not os.path.exists(path):
                continue
            with open(path, "rb") as f:
                files_payload = {"file": (os.path.basename(path), f, "image/png")}
                try:
                    r = requests.post(url, headers=headers, auth=auth, files=files_payload, timeout=60)
                    _ = r.status_code  # ignore errors silently in demo
                except Exception:
                    pass
