DROP TABLE IF EXISTS transactions;
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY,
  name TEXT,
  amount REAL,
  created_at TEXT
);
