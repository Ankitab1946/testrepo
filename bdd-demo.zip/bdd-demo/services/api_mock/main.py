from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
import os
from app.config import settings

app = FastAPI(title="Mock API & UI")

@app.get("/")
def root():
    return {"hello": "world"}

@app.get("/score")
def score(client: str = "A"):
    # Simple, deterministic demo response
    value = 87 if client.upper() == "A" else 42
    return JSONResponse({"client": client.upper(), "score": value})

@app.get("/clients", response_class=HTMLResponse)
def clients():
    revenue_a = settings.expected_revenue_client_a
    html = f"""
    <html><head><title>Clients</title></head>
    <body>
      <h1>Client Revenue</h1>
      <table id="clients" border="1">
        <thead><tr><th>Client</th><th>Revenue</th></tr></thead>
        <tbody>
          <tr><td>A</td><td>{revenue_a}</td></tr>
          <tr><td>B</td><td>75000</td></tr>
        </tbody>
      </table>
    </body></html>
    """
    return HTMLResponse(html)
