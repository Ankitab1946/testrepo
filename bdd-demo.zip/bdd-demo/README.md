# BDD + Gherkin End‑to‑End Demo

Plain English → Gherkin (AWS Bedrock) → Behave execution (DB/API/UI) → Cucumber JSON → Xray upload.  
Includes Streamlit UI, SQLite demo DB, FastAPI mock services, Great Expectations check, and Selenium UI validation.

## Quick Start

```bash
python -m venv .venv
# Windows:
. .venv/Scripts/activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt

# (optional) copy sample env
cp sample.env .env

# start mock API & UI
uvicorn services.api_mock.main:app --reload --port 9000

# start the Streamlit app
streamlit run app/streamlit_app.py
```

### Running tests from CLI
```bash
python scripts/run_behave.py
pytest tests/pytest -q
```

## Features covered

1. **Feed → DB validation** (SQLite by default; switch to SQL Server via `.env`)
   - Row count parity
   - Column types

2. **API data quality** using Great Expectations
   - Range check for `score` in [0, 100]

3. **UI validation** using Selenium
   - Assert revenue for Client A equals `EXPECTED_REVENUE_CLIENT_A`

## Bedrock (English → Gherkin)

Set AWS credentials in `.env` and ensure you have access to the model specified by `BEDROCK_MODEL`.  
If Bedrock is not configured, the app falls back to simple Gherkin templates.

## Xray Upload

- **Cloud**: provide `XRAY_CLIENT_ID/SECRET` (OAuth2) and `JIRA_BASE_URL`.  
- **Server/DC**: set `JIRA_BASE_URL`, `JIRA_USER_EMAIL`, `JIRA_API_TOKEN`.

Use the Streamlit button **Upload Result to Xray** or CLI:
```bash
python scripts/upload_to_xray.py
```

In demo mode (no credentials), upload is simulated and a JSON log is written under `reports/`.

## Notes
- Great Expectations API varies by version; this project includes a graceful fallback to a simple Python range check.
- Selenium requires Chrome installed. Headless mode is default; toggle `HEADLESS=false` in `.env` for visible runs.
- SQLite database file is created at `data/demo.sqlite` automatically.
